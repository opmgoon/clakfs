﻿namespace Client
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.Code_btn = new System.Windows.Forms.Button();
            this.sender_btn = new System.Windows.Forms.Button();
            this.listbox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Code_btn
            // 
            this.Code_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Code_btn.Location = new System.Drawing.Point(20, 20);
            this.Code_btn.Name = "Code_btn";
            this.Code_btn.Size = new System.Drawing.Size(75, 75);
            this.Code_btn.TabIndex = 0;
            this.Code_btn.Text = "Genera Codice";
            this.Code_btn.UseVisualStyleBackColor = true;
            this.Code_btn.Click += new System.EventHandler(this.Code_btn_Click);
            // 
            // sender_btn
            // 
            this.sender_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sender_btn.Location = new System.Drawing.Point(582, 20);
            this.sender_btn.Name = "sender_btn";
            this.sender_btn.Size = new System.Drawing.Size(73, 75);
            this.sender_btn.TabIndex = 1;
            this.sender_btn.Text = "Invia il codice al server";
            this.sender_btn.UseVisualStyleBackColor = true;
            this.sender_btn.Click += new System.EventHandler(this.sender_btn_Click);
            // 
            // listbox
            // 
            this.listbox.Location = new System.Drawing.Point(115, 20);
            this.listbox.Multiline = true;
            this.listbox.Name = "listbox";
            this.listbox.Size = new System.Drawing.Size(447, 75);
            this.listbox.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.listbox);
            this.Controls.Add(this.sender_btn);
            this.Controls.Add(this.Code_btn);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Code_btn;
        private System.Windows.Forms.Button sender_btn;
        private System.Windows.Forms.TextBox listbox;
    }
}

