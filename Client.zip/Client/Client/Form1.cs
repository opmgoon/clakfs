﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Code_btn_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            int a = random.Next(1,50);
            string c = null;
            for (int i = 0; i < a; i++)
            {
                int b = random.Next(1, 9);
                c = c + Convert.ToString(b);
            }
            listbox.Text = c;
        }

        private void sender_btn_Click(object sender, EventArgs e)
        {

        }
    }
}
